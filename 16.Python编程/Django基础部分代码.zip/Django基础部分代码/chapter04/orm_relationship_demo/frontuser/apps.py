from django.apps import AppConfig


class FrontuserConfig(AppConfig):
    name = 'frontuser'
