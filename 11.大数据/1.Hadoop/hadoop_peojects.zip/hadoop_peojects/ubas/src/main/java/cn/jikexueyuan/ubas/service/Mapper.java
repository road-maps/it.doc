package cn.jikexueyuan.ubas.service;

/**
 * @Date Mar 24, 2015
 *
 * @Author dengjie
 *
 * @Note To the outside to provide a unified inheritance structure
 */
public interface Mapper {

}
