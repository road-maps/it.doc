# User Agent Parser

Java port of the (https://github.com/yammer/user_agent) Ruby user agent parser. 

# Usage

	UserAgentParser userAgentParser  = new UserAgentParser();
	UserAgent agent = userAgentParser.parse(source);
	
# License

MIT License, See LICENSE.txt for details